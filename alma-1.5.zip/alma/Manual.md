# ALMA 사용 설명서

**Agent Lifecycle Manager** — PostgreSQL Extension 기반 AI 에이전트 라이프사이클 관리 프레임워크

---

## 목차

1. [개요 및 설계 철학](#1-개요-및-설계-철학)
2. [시스템 요구사항](#2-시스템-요구사항)
3. [설치](#3-설치)
4. [핵심 개념](#4-핵심-개념)
5. [에이전트 생성 및 관리](#5-에이전트-생성-및-관리)
6. [에이전트 실행](#6-에이전트-실행)
7. [멀티 에이전트](#7-멀티-에이전트)
8. [워커 운영](#8-워커-운영)
9. [SQL 샌드박스](#9-sql-샌드박스)
10. [로그 압축 에이전트](#10-로그-압축-에이전트)
11. [시스템 에이전트 관리](#11-시스템-에이전트-관리)
12. [모니터링 및 감사](#12-모니터링-및-감사)
13. [대시보드](#13-대시보드)
14. [보안 모델](#14-보안-모델)
15. [테이블 및 뷰 레퍼런스](#15-테이블-및-뷰-레퍼런스)
16. [함수 레퍼런스](#16-함수-레퍼런스)
17. [트러블슈팅](#17-트러블슈팅)

---

## 1. 개요 및 설계 철학

ALMA는 PostgreSQL을 AI 에이전트의 **컨트롤 플레인**으로 사용합니다.

### 핵심 원칙

**DB는 상태만 가진다.**
LLM API 호출은 외부 워커(`alma_agent.py`)가 담당합니다. DB는 "다음에 뭘 해야 하는가"를 결정하고, 워커는 그 지시에 따라 HTTP 요청만 수행합니다. DB 커넥션이 LLM 응답 대기 시간(수십 초)에 묶이지 않습니다.

**에이전트는 PostgreSQL Role이다.**
에이전트 = DB 접속 계정. 롤로 접속하면 자신에게 허용된 것만 볼 수 있습니다. 새 에이전트 추가는 `create_agent()` 호출 한 번으로 완료됩니다.

**tasks 테이블이 메시지 큐다.**
에이전트 간 통신과 작업 스케줄링은 모두 `tasks` 테이블로 통합됩니다. `pg_notify`가 실시간 알림을 담당하므로 별도 큐 시스템이 필요 없습니다.

**트랜잭션이 일관성을 보장한다.**
모든 상태 변경은 PostgreSQL 트랜잭션으로 처리됩니다. 장애 발생 시 WAL로 자동 복구됩니다.

### 아키텍처 개요

```
┌──────────────────────────────────────────────────────┐
│                    외부 워커                           │
│  alma_agent.py --worker                               │
│    ├── fn_next_step()  호출  → DB가 지시 반환         │
│    ├── LLM API HTTP 호출     (워커만 담당)            │
│    └── fn_submit_result() 호출 → DB가 상태 갱신       │
└─────────────────────────┬────────────────────────────┘
                          │ psycopg2
┌─────────────────────────▼────────────────────────────┐
│                  PostgreSQL + ALMA                     │
│                                                        │
│  alma_public (에이전트 접근 가능)                      │
│    ├── run_agent()         태스크 큐잉 → task_id 반환 │
│    ├── fn_next_step()      다음 지시 반환             │
│    ├── fn_submit_result()  결과 수신 + 상태 갱신      │
│    ├── v_ready_tasks       실행 가능 태스크 뷰        │
│    └── v_session_progress  세션 진행 상황             │
│                                                        │
│  alma_private (operator만 직접 접근)                  │
│    ├── tasks               메시지 큐                  │
│    ├── execution_logs      스텝별 실행 이력           │
│    ├── sessions            실행 단위                  │
│    └── memory              에이전트 장기 기억         │
└──────────────────────────────────────────────────────┘
```

---

## 2. 시스템 요구사항

| 항목 | 최소 요구사항 |
|------|--------------|
| PostgreSQL | 15 이상 |
| pgvector | 0.5.0 이상 |
| plpython3u | PostgreSQL 버전과 동일 |
| pgcrypto | PostgreSQL 내장 |
| Python | 3.9 이상 (워커용) |
| LLM | Ollama(로컬), OpenAI, Anthropic, 호환 API |

**Ubuntu/Debian 의존성 설치:**
```bash
sudo apt install postgresql-16 \
                 postgresql-16-pgvector \
                 postgresql-plpython3-16
```

---

## 3. 설치

### 3.1 Extension 설치

```bash
# 빌드 및 설치
cd alma
make install

# DB에 Extension 생성
psql -U postgres -c "CREATE EXTENSION alma;"
```

### 3.2 초기 설정

```sql
-- alma_operator 권한을 관리자 계정에 부여
GRANT alma_operator TO postgres;

-- 설치 확인
SELECT extname, extversion FROM pg_extension WHERE extname = 'alma';
```

### 3.3 Python 의존성 (워커용)

```bash
pip install -r sample/requirements.txt
# psycopg2-binary, streamlit, pandas
```

---

## 4. 핵심 개념

### 4.1 에이전트 역할 (agent_role)

| 역할 | 설명 |
|------|------|
| `executor` | 실제 작업을 수행 (SQL 조회, 분석 등) |
| `orchestrator` | 다른 에이전트에게 작업을 위임하는 조율자 |
| `evaluator` | 결과를 평가하거나 품질을 검증 |

### 4.2 태스크 상태 흐름

```
pending → running → completed
                 ↘ failed
                 ↘ cancelled
```

- `pending`: 워커가 아직 처리하지 않은 상태
- `running`: 워커가 LLM 호출 중
- `completed`: 최종 답변 확정
- `failed`: 오류로 인한 실패
- `cancelled`: 운영자에 의한 취소

### 4.3 세션과 태스크의 관계

세션은 최상위 실행 단위입니다. 하나의 세션 안에 여러 태스크가 있을 수 있습니다.

- 단일 에이전트: 세션 1개 → 태스크 1개
- 멀티 에이전트: 세션 1개 → 오케스트레이터 태스크 1개 + 서브태스크 N개

### 4.4 LLM 응답 포맷

에이전트 LLM은 반드시 아래 JSON 포맷 중 하나로 응답해야 합니다.

**작업 완료:**
```json
{
  "thought": "분석 완료. 결과를 반환합니다.",
  "action": "finish",
  "final_answer": "최종 답변 내용"
}
```

**SQL 실행 (allowlist에 등록된 뷰만 가능):**
```json
{
  "thought": "태스크 목록을 조회하겠습니다.",
  "action": "execute_sql",
  "sql": "SELECT task_id, status FROM alma_public.v_my_tasks"
}
```

**멀티 에이전트 위임 (orchestrator만):**
```json
{
  "thought": "두 에이전트에게 작업을 분배합니다.",
  "action": "delegate",
  "subtasks": [
    {"agent_role": "agent_sql",      "task": "매출 데이터 조회"},
    {"agent_role": "agent_analyst",  "task": "조회 결과 분석"}
  ]
}
```

---

## 5. 에이전트 생성 및 관리

### 5.1 에이전트 생성

`create_agent()`는 PostgreSQL Role 생성 + LLM 설정 + 프로필 등록을 한 번에 처리합니다.
`alma_operator` 권한이 있는 계정으로 실행해야 합니다.

```sql
SELECT alma_public.create_agent(
    'agent_sql',       -- PostgreSQL Role 이름 (로그인 계정)
    '{
        "name":          "SQL 분석 에이전트",
        "agent_role":    "executor",
        "provider":      "ollama",
        "endpoint":      "http://localhost:11434/api/chat",
        "model_name":    "gpt-oss:20b",
        "temperature":   0.0,
        "max_tokens":    4096,
        "request_options": {"format": "json"},
        "system_prompt": "당신은 PostgreSQL 전문가입니다. 항상 JSON으로 응답하세요.\n작업 완료: {\"thought\":\"...\",\"action\":\"finish\",\"final_answer\":\"...\"}\nSQL 실행: {\"thought\":\"...\",\"action\":\"execute_sql\",\"sql\":\"SELECT ...\"}",
        "max_steps":     10,
        "max_retries":   3
    }'::jsonb
);
```

**필수 키:**

| 키 | 설명 |
|----|------|
| `name` | 에이전트 표시명 |
| `agent_role` | `executor` / `orchestrator` / `evaluator` |
| `provider` | `ollama` / `openai` / `anthropic` / `custom` |
| `model_name` | 사용할 모델명 |

**선택 키:**

| 키 | 기본값 | 설명 |
|----|--------|------|
| `endpoint` | provider 기본값 | API 엔드포인트 URL |
| `api_key_ref` | NULL | API 키 환경변수명 (키 자체 아님) |
| `temperature` | 0.7 | 0.0 ~ 2.0 |
| `max_tokens` | 4096 | 최대 출력 토큰 수 |
| `request_options` | NULL | provider별 추가 옵션 JSONB |
| `system_prompt` | `''` | 시스템 프롬프트 |
| `max_steps` | 10 | 최대 실행 스텝 수 |
| `max_retries` | 3 | 최대 재시도 횟수 |
| `password` | 자동 생성 | DB 로그인 비밀번호 |
| `embedding_model` | NULL | 임베딩 모델명 (메모리 RAG 사용 시) |

**provider별 기본 endpoint:**

| provider | 기본 endpoint |
|----------|---------------|
| `anthropic` | `https://api.anthropic.com/v1/messages` |
| `openai` | `https://api.openai.com/v1/chat/completions` |
| `ollama` | `http://localhost:11434/api/chat` |
| `custom` | 필수 입력 |

### 5.2 에이전트 목록 조회

```sql
SELECT * FROM alma_public.list_agents();
```

### 5.3 에이전트 설정 수정

```sql
-- 시스템 프롬프트 변경
UPDATE alma_private.agent_profiles
SET system_prompt = '새로운 시스템 프롬프트'
WHERE name = 'SQL 분석 에이전트';

-- LLM 모델 변경 (서비스 재시작 없음)
UPDATE alma_private.llm_configs
SET model_name  = 'qwen3:14b',
    temperature = 0.1
WHERE llm_config_id = (
    SELECT llm_config_id
    FROM alma_private.agent_profile_assignments
    WHERE role_name = 'agent_sql'
);

-- 최대 스텝 수 변경
UPDATE alma_private.agent_profiles
SET max_steps = 20
WHERE profile_id = (
    SELECT profile_id
    FROM alma_private.agent_profile_assignments
    WHERE role_name = 'agent_sql'
);
```

### 5.4 에이전트 비활성화 / 활성화

```sql
-- 비활성화 (롤 삭제 없이 일시 중단)
UPDATE alma_private.agent_meta
SET is_active = FALSE
WHERE role_name = 'agent_sql';

-- 활성화
UPDATE alma_private.agent_meta
SET is_active = TRUE
WHERE role_name = 'agent_sql';
```

### 5.5 에이전트 삭제

```sql
-- 에이전트와 모든 관련 데이터 영구 삭제 (복구 불가)
SELECT alma_public.drop_agent('agent_sql');
```

---

## 6. 에이전트 실행

### 6.1 run_agent() — 태스크 등록

`run_agent()`는 태스크를 `tasks` 테이블에 `pending` 상태로 등록하고 `task_id`를 즉시 반환합니다.
실제 LLM 실행은 워커(`--worker` 모드)가 담당합니다.

```sql
-- agent_sql 롤로 DB에 접속한 후 실행
SELECT alma_public.run_agent(
    'agent_sql',                    -- 에이전트 role_name (session_user와 일치해야 함)
    'show me all tables in alma'    -- 태스크 지시문
);
-- 반환값: task_id (INT)
```

**이전 세션 이어하기:**
```sql
SELECT alma_public.run_agent(
    'agent_sql',
    '이전 결과를 바탕으로 추가 분석해줘',
    42,   -- p_session_id: 이어갈 세션 ID
    5,    -- p_memory_limit: 장기 메모리 참조 개수
    20    -- p_history_steps: 이전 대화 복원 스텝 수
);
```

### 6.2 결과 확인

태스크 등록 직후 워커가 처리를 시작합니다. 폴링 또는 pg_notify로 완료를 확인합니다.

**폴링 방식 (psql):**
```sql
-- 태스크 상태 및 결과 확인
SELECT task_id, status, output
FROM alma_public.v_my_tasks
WHERE task_id = 42;
```

**LISTEN 방식 (Python):**
```python
import psycopg2, select, json

conn = psycopg2.connect("dbname=postgres user=agent_sql password=...")
conn.autocommit = True
conn.cursor().execute("LISTEN alma_session_done;")

# 완료 알림 대기
select.select([conn], [], [])
conn.poll()
notify = conn.notifies.pop(0)
result = json.loads(notify.payload)
print(result["final_answer"])
```

### 6.3 Python CLI로 실행

```bash
# 환경변수 설정
export DB_NAME=postgres
export DB_USER=agent_sql
export DB_PASSWORD=<비밀번호>

# 태스크 등록 (task_id 출력)
python3 sample/alma_agent.py agent_sql "show me all tables"
# → Task enqueued. task_id=5

# 별도 터미널에서 워커 실행 (항상 미리 실행되어 있어야 함)
python3 sample/alma_agent.py --worker agent_sql
```

---

## 7. 멀티 에이전트

오케스트레이터 에이전트가 다른 에이전트에게 서브태스크를 위임하는 구조입니다.

### 7.1 오케스트레이터 생성

```sql
SELECT alma_public.create_agent(
    'agent_orchestrator',
    '{
        "name":        "오케스트레이터",
        "agent_role":  "orchestrator",
        "provider":    "ollama",
        "model_name":  "gpt-oss:20b",
        "temperature": 0.0,
        "request_options": {"format": "json"},
        "system_prompt": "당신은 작업을 조율하는 오케스트레이터입니다. 항상 JSON으로 응답하세요.\n\n서브에이전트 위임:\n{\"thought\":\"...\",\"action\":\"delegate\",\"subtasks\":[{\"agent_role\":\"agent_sql\",\"task\":\"...\"}]}\n\n완료:\n{\"thought\":\"...\",\"action\":\"finish\",\"final_answer\":\"...\"}",
        "max_steps": 5
    }'::jsonb
);
```

### 7.2 멀티 에이전트 실행

```sql
-- 오케스트레이터 롤로 접속한 후
SELECT alma_public.run_multi_agent(
    'agent_orchestrator',
    '월별 매출을 분석하고 이상치를 탐지해서 보고서를 작성해줘'
);
-- 반환값: task_id (INT)
```

### 7.3 서브에이전트 실행 흐름

```
오케스트레이터 워커
  → fn_next_step()   → {action: call_llm, messages, llm_config}
  → LLM HTTP 호출   → {"action":"delegate","subtasks":[...]}
  → fn_submit_result() → tasks에 서브태스크 INSERT (pending)
                       → task_dependencies에 DAG 순서 INSERT
                       → {action: continue}
  → 서브에이전트 워커들이 v_ready_tasks 폴링
  → 서브태스크 순서대로 실행 완료
  → 오케스트레이터 fn_next_step() 재호출
  → LLM이 결과 수집 후 {"action":"finish",...}
```

### 7.4 태스크 의존관계 확인

```sql
-- 세션 내 의존관계 DAG 확인
SELECT
    td.task_id,
    td.depends_on_task_id,
    t1.input  AS task_input,
    t2.status AS dep_status
FROM alma_private.task_dependencies td
JOIN alma_private.tasks t1 ON t1.task_id = td.task_id
JOIN alma_private.tasks t2 ON t2.task_id = td.depends_on_task_id
WHERE t1.session_id = <session_id>;
```

---

## 8. 워커 운영

### 8.1 워커 실행

워커는 `v_ready_tasks`를 폴링하거나 `pg_notify`를 LISTEN하여 새 태스크를 감지하고, `fn_next_step` / `fn_submit_result` 루프로 실행합니다.

```bash
# 기본 실행
export DB_USER=agent_sql
export DB_PASSWORD=<비밀번호>
python3 sample/alma_agent.py --worker agent_sql

# 폴링 간격 조정 (기본 1.0초)
export ALMA_WORKER_POLL_SEC=0.5
python3 sample/alma_agent.py --worker agent_sql
```

### 8.2 워커 동작 원리

```
while True:
  ┌─ pg_notify 수신 or 폴링 대기
  │
  ├─ v_ready_tasks 조회 (의존관계 완료된 pending 태스크)
  │    FOR UPDATE SKIP LOCKED (복수 워커 중복 실행 방지)
  │
  ├─ status = 'running'으로 전환
  │
  └─ fn_next_step/fn_submit_result 루프
       ├─ fn_next_step(task_id) → {action:"call_llm", messages, llm_config}
       ├─ LLM HTTP 호출 (동기, 워커만 담당)
       ├─ fn_submit_result(task_id, response)
       │    → DB가 상태 갱신 + 다음 액션 결정
       │    → {action:"continue"} → 루프 반복
       └─ {action:"done"} → 다음 태스크로
```

### 8.3 복수 에이전트 병렬 워커

에이전트 롤마다 별도 프로세스를 실행합니다.

```bash
# 터미널 1 — SQL 에이전트 워커
DB_USER=agent_sql DB_PASSWORD=pw1 \
  python3 sample/alma_agent.py --worker agent_sql

# 터미널 2 — 분석 에이전트 워커
DB_USER=agent_analyst DB_PASSWORD=pw2 \
  python3 sample/alma_agent.py --worker agent_analyst

# 터미널 3 — 오케스트레이터 워커
DB_USER=agent_orchestrator DB_PASSWORD=pw3 \
  python3 sample/alma_agent.py --worker agent_orchestrator
```

### 8.4 pg_notify 채널

| 채널 | 발생 시점 | 페이로드 키 |
|------|-----------|-------------|
| `alma_task_ready` | pending 태스크 생성 시 | `task_id`, `session_id`, `agent_id` |
| `alma_session_done` | 세션 완료/실패 시 | `session_id`, `status`, `agent_id`, `final_answer` |

---

## 9. SQL 샌드박스

에이전트가 `execute_sql` 액션으로 실행하는 쿼리는 `sql_sandbox_allowlist`에 등록된 뷰만 조회할 수 있습니다.

### 9.1 허용 목록 관리

```sql
-- 현재 허용 목록 확인
SELECT * FROM alma_private.sql_sandbox_allowlist;

-- 새 뷰 허용 추가
INSERT INTO alma_private.sql_sandbox_allowlist (view_name, description)
VALUES ('alma_public.v_session_progress', '세션 진행 상황');

-- 허용 취소
DELETE FROM alma_private.sql_sandbox_allowlist
WHERE view_name = 'alma_public.v_session_progress';
```

**기본 허용 목록:**

| 뷰 | 설명 |
|----|------|
| `alma_public.v_my_tasks` | 자신의 태스크 목록 |
| `alma_public.v_my_memory` | 자신의 장기 메모리 |
| `alma_public.v_session_progress` | 세션 진행 현황 |
| `alma_public.v_ready_tasks` | 실행 가능한 태스크 |

### 9.2 샌드박스 보호 방식

`fn_execute_sql`은 두 단계로 보호됩니다.

1. **allowlist 검사**: FROM 절 대상이 허용 목록에 있는지 확인
2. **`SET LOCAL ROLE alma_sql_sandbox`**: 트랜잭션 내에서 권한 축소 (정규식 우회 불가)

`alma_sql_sandbox` 롤은 허용된 뷰에만 SELECT 권한을 가지므로, 정규식을 우회해도 권한 자체가 없어 실행이 차단됩니다.

---

## 10. 로그 압축 에이전트

실행 로그가 일정 수 이상 쌓이면 LLM이 핵심 추론 과정만 요약해 보존합니다. 원본은 압축 품질 검증 후에만 삭제됩니다.

### 10.1 압축 에이전트 활성화

**1단계: 압축 에이전트 생성**
```sql
-- system_prompt를 비워두면 Extension 내장 프롬프트 자동 사용
SELECT alma_public.create_agent(
    'alma_compressor',
    '{
        "name":           "ALMA Log Compressor",
        "agent_role":     "evaluator",
        "provider":       "ollama",
        "endpoint":       "http://localhost:11434/api/chat",
        "model_name":     "gpt-oss:20b",
        "temperature":    0.0,
        "max_tokens":     4096,
        "request_options": {"format": "json"},
        "max_steps":      20
    }'::jsonb
);
```

**2단계: 시스템 에이전트에 연결 및 활성화**
```sql
UPDATE alma_private.system_agent_configs
SET role_name  = 'alma_compressor',
    is_enabled = TRUE
WHERE agent_type = 'compressor';
```

**3단계: 압축 워커 실행**
```bash
export DB_USER=alma_compressor
export DB_PASSWORD=<비밀번호>
python3 sample/alma_agent.py --compressor alma_compressor
```

### 10.2 압축 품질 관리

압축 에이전트는 스스로 품질 점수를 매기고 기준 미달이면 재시도합니다.

| 점수 | 의미 |
|------|------|
| 1.00 | 모든 추론 스텝 완전 복원 가능 |
| 0.95 | 불필요한 패딩 제거. 모든 결정과 결과 보존 |
| 0.90 | 사소한 중간 세부사항 손실. 핵심 로직 완전 보존 |
| 0.85 | 일부 추론 스텝 요약. 결론 추적 가능 |
| 0.80 | 눈에 띄는 압축. 핵심 사실 보존 |
| 0.80 미만 | 재압축 필요 (제출 불가) |

### 10.3 압축 설정 조정

```sql
-- 현재 설정 및 현황 확인
SELECT * FROM alma_public.v_system_agents;

-- 품질 임계값 상향 (더 엄격하게)
UPDATE alma_private.system_agent_configs
SET settings = settings || '{"quality_threshold": 0.95}'
WHERE agent_type = 'compressor';

-- 압축 대상 임계값 하향 (로그 10개 이상이면 압축)
UPDATE alma_private.system_agent_configs
SET settings = settings || '{"compress_after_steps": 10}'
WHERE agent_type = 'compressor';

-- 실행 주기 변경 (6시간마다)
UPDATE alma_private.system_agent_configs
SET run_interval_secs = 21600
WHERE agent_type = 'compressor';

-- 비활성화
UPDATE alma_private.system_agent_configs
SET is_enabled = FALSE
WHERE agent_type = 'compressor';
```

**settings 항목 전체:**

| 키 | 기본값 | 설명 |
|----|--------|------|
| `quality_threshold` | 0.9 | 이 이상이면 원본 삭제 |
| `retry_threshold` | 0.8 | 이 이상이면 재시도 없이 저장 |
| `max_retries` | 2 | 품질 미달 시 재시도 횟수 |
| `compress_after_steps` | 20 | 로그 몇 개 이상일 때 압축 대상 |
| `tool_result_max_chars` | 300 | 이 이상이면 tool 결과 요약 |
| `batch_size` | 5 | 한 번에 처리할 태스크 수 |

### 10.4 압축 상태 확인

```sql
-- 압축 대기 중인 태스크 목록
SELECT * FROM alma_public.v_compressible_logs;

-- 특정 태스크의 압축 상태
SELECT
    log_id, step_number, role,
    compressed_at,
    compression_quality,
    CASE WHEN compressed_at IS NOT NULL THEN '압축완료' ELSE '미압축' END AS compress_status
FROM alma_private.execution_logs
WHERE task_id = <task_id>
ORDER BY step_number;
```

### 10.5 수동 원본 삭제

```sql
-- 기본 임계값(0.9)으로 검증 후 삭제
SELECT alma_public.fn_purge_compressed_logs(<task_id>);

-- 임계값 직접 지정
SELECT alma_public.fn_purge_compressed_logs(<task_id>, 0.95);
```

품질이 임계값 미만인 로그가 하나라도 있으면 오류가 발생하고 삭제되지 않습니다.

---

## 11. 시스템 에이전트 관리

`v_system_agents` 뷰와 `system_agent_configs` 테이블로 시스템 에이전트를 SQL 한 줄로 제어합니다.

```sql
-- 전체 현황 (alma_operator 전용)
SELECT
    agent_type,
    is_enabled,
    role_name,
    run_interval_secs,
    last_run_at,
    next_run_at,
    pending_targets,    -- 압축 대기 태스크 수
    settings
FROM alma_public.v_system_agents;
```

**표시 항목 설명:**

| 컬럼 | 설명 |
|------|------|
| `is_enabled` | 활성화 여부 (TRUE/FALSE) |
| `role_name` | 연결된 에이전트 DB 롤 |
| `run_interval_secs` | 실행 주기 (초) |
| `last_run_at` | 마지막 실행 시각 |
| `next_run_at` | 다음 실행 예정 시각 |
| `pending_targets` | 처리 대기 중인 항목 수 |
| `settings` | 세부 설정 JSONB |

---

## 12. 모니터링 및 감사

### 12.1 세션 진행 상황

```sql
-- 내 세션 현황 (에이전트 롤로 접속 시 자신의 것만 표시)
SELECT * FROM alma_public.v_session_progress
ORDER BY session_id DESC;

-- 특정 세션 상세 감사 로그
SELECT * FROM alma_public.get_session(<session_id>);
```

### 12.2 태스크 모니터링

```sql
-- 현재 실행 중인 태스크
SELECT task_id, session_id, status, input, created_at, updated_at
FROM alma_private.tasks
WHERE status = 'running'
ORDER BY created_at;

-- 실행 가능 태스크 (워커 대기 중)
SELECT * FROM alma_public.v_ready_tasks;

-- 실패한 태스크
SELECT task_id, session_id, input, output, updated_at
FROM alma_private.tasks
WHERE status = 'failed'
ORDER BY updated_at DESC;
```

### 12.3 전체 감사 로그 (operator)

```sql
-- 전체 실행 이력 (세션 → 태스크 → 스텝 순)
SELECT * FROM alma_public.v_session_audit
ORDER BY session_id DESC, task_id, step_number
LIMIT 100;
```

### 12.4 에이전트 메모리 조회

```sql
-- 특정 에이전트의 장기 메모리
SELECT m.memory_id, m.session_id, m.content, m.created_at
FROM alma_private.memory m
JOIN alma_private.agent_meta am ON m.agent_id = am.agent_id
WHERE am.role_name = 'agent_sql'
ORDER BY m.created_at DESC;
```

### 12.5 에이전트 간 메시지 감사

```sql
-- 멀티 에이전트 세션의 메시지 흐름
SELECT
    am_from.role_name AS from_agent,
    am_to.role_name   AS to_agent,
    msg.direction,
    msg.content,
    msg.created_at
FROM alma_private.agent_messages msg
JOIN alma_private.agent_meta am_from ON am_from.agent_id = msg.from_agent_id
JOIN alma_private.agent_meta am_to   ON am_to.agent_id   = msg.to_agent_id
WHERE msg.session_id = <session_id>
ORDER BY msg.created_at;
```

---

## 13. 대시보드

Streamlit 기반 웹 관리 UI를 제공합니다.

```bash
streamlit run sample/alma_dashboard.py
# 기본 접속: http://localhost:8501
```

**메뉴 구성:**

| 메뉴 | 주요 기능 |
|------|-----------|
| DB 연결 | PostgreSQL 연결 설정 및 테스트 |
| 에이전트 관리 | 생성 / 설정 수정 / 삭제 / 목록 |
| 에이전트 실행 | 태스크 등록, 비밀번호 관리 |
| 세션 모니터링 | 진행 현황 / 감사 로그 / 스텝별 상세 보기 |
| 테이블 탐색기 | alma_private 테이블 직접 조회 |
| 실험 관리 | 벤치마크 등록 및 결과 비교 |

---

## 14. 보안 모델

### 14.1 역할 계층

```
alma_operator               인간 운영자
│  alma_private 전체 + alma_public 전체
│
└── alma_agent_base          에이전트 공통 베이스
    │  alma_public 지정 뷰/함수만
    │
    ├── agent_sql            SQL 분석 에이전트
    ├── agent_analyst        분석 에이전트
    └── agent_orchestrator   오케스트레이터

alma_sql_sandbox             fn_execute_sql 전용
   허용 뷰에만 SELECT (트랜잭션 내 SET LOCAL ROLE로만 사용)
```

### 14.2 에이전트 격리

모든 에이전트 공개 뷰는 `WHERE role_name = session_user::text`로 자동 필터링됩니다.

```sql
-- agent_sql로 접속 시: agent_sql의 태스크만 보임
SELECT * FROM alma_public.v_my_tasks;

-- 다른 에이전트 태스크는 볼 수 없음 (뷰 정의로 차단)
```

### 14.3 API 키 보안

API 키는 **절대 DB에 저장하지 않습니다.**  
`api_key_ref` 컬럼에는 환경변수명만 저장합니다.

```sql
-- 올바른 방법: 환경변수명만 저장
"api_key_ref": "ANTHROPIC_API_KEY"

-- 절대 하지 말 것
"api_key_ref": "sk-ant-xxxx..."
```

워커 실행 시 환경변수로 설정:
```bash
export ANTHROPIC_API_KEY=sk-ant-xxxx...
python3 sample/alma_agent.py --worker agent_claude
```

### 14.4 run_agent() 권한 검사

`run_agent()`는 `session_user`와 `p_agent_role`이 일치하지 않으면 실행을 거부합니다.

```sql
-- agent_sql로 접속해야만 아래 호출 가능
SELECT alma_public.run_agent('agent_sql', '...');

-- postgres로 접속 후 다른 에이전트 사칭 → 오류
SELECT alma_public.run_agent('agent_sql', '...');
-- ERROR: run_agent: permission denied — session_user (postgres) cannot run as agent (agent_sql)
```

---

## 15. 테이블 및 뷰 레퍼런스

### alma_private 테이블 (alma_operator 직접 접근)

| 테이블 | 설명 |
|--------|------|
| `llm_configs` | LLM 모델 설정 (provider, endpoint, model_name, temperature, max_tokens …) |
| `agent_profiles` | 에이전트 행동 프로필 (system_prompt, max_steps, max_retries) |
| `agent_meta` | 에이전트 ID (role_name ↔ PostgreSQL Role 연결, is_active) |
| `agent_profile_assignments` | 에이전트 ↔ 프로필 + LLM 1:1 매핑 |
| `sessions` | 실행 단위 (goal, status, final_answer) |
| `tasks` | 태스크 큐 (input, output, status — 메시지 버스) |
| `execution_logs` | 스텝별 실행 이력 (role, content, compressed_content, compression_quality) |
| `memory` | 에이전트 장기 기억 (content, embedding: pgvector) |
| `task_dependencies` | 태스크 DAG 의존관계 |
| `agent_messages` | 에이전트 간 메시지 감사 로그 |
| `human_interventions` | 운영자 개입 감사 로그 |
| `experiments` | 벤치마크 정의 |
| `experiment_results` | 벤치마크 결과 |
| `sql_sandbox_allowlist` | fn_execute_sql 허용 뷰 목록 |
| `system_agent_configs` | 시스템 에이전트 설정 (is_enabled, settings JSONB) |

### alma_public 뷰

| 뷰 | 접근 권한 | 설명 |
|----|-----------|------|
| `v_agent_context` | 에이전트 | 자신의 프로필 + LLM 설정 |
| `v_my_tasks` | 에이전트 | 자신의 태스크 목록 |
| `v_my_memory` | 에이전트 | 자신의 장기 메모리 |
| `v_session_progress` | 에이전트 / operator | 세션 진행 현황 (에이전트는 자신의 것만) |
| `v_ready_tasks` | 에이전트 / operator | 의존관계가 완료된 pending 태스크 |
| `v_session_audit` | operator | 전체 감사 로그 (세션→태스크→스텝) |
| `v_compressible_logs` | operator | 압축 대상 태스크 (로그 수 ≥ compress_after_steps) |
| `v_system_agents` | operator | 시스템 에이전트 현황 + next_run_at + pending_targets |

---

## 16. 함수 레퍼런스

### 에이전트 관리 (alma_operator 전용)

| 함수 시그니처 | 반환 | 설명 |
|--------------|------|------|
| `create_agent(role_name TEXT, config JSONB)` | TEXT | 에이전트 생성 |
| `drop_agent(role_name TEXT)` | TEXT | 에이전트 영구 삭제 |
| `list_agents()` | TABLE | 에이전트 목록 |
| `fn_purge_compressed_logs(task_id INT, quality_threshold FLOAT DEFAULT 0.9)` | INT (삭제 행 수) | 압축 완료 로그 원본 삭제 |

### 에이전트 실행 (alma_agent_base)

| 함수 시그니처 | 반환 | 설명 |
|--------------|------|------|
| `run_agent(agent_role TEXT, task TEXT, session_id INT DEFAULT NULL, memory_limit INT DEFAULT 5, history_steps INT DEFAULT 20)` | INT (task_id) | 태스크 큐잉 |
| `run_multi_agent(orchestrator_role TEXT, goal TEXT)` | INT (task_id) | 멀티 에이전트 태스크 큐잉 |
| `fn_next_step(task_id INT)` | JSONB | 다음 지시 반환 (워커용) |
| `fn_submit_result(task_id INT, response TEXT, is_final BOOLEAN DEFAULT FALSE)` | JSONB | LLM 결과 제출 |
| `fn_search_memory(query_embedding vector, limit INT DEFAULT 5)` | TABLE | 의미 유사도 메모리 검색 |
| `list_sessions(agent_role TEXT DEFAULT NULL)` | TABLE | 세션 목록 |
| `get_session(session_id INT)` | TABLE | 세션 상세 감사 로그 |

### fn_next_step 반환 포맷

```jsonc
// LLM 호출 필요 시
{
  "action":     "call_llm",
  "task_id":    42,
  "agent_id":   3,
  "messages":   [...],          // 시스템 + 이전 대화 + 현재 입력
  "llm_config": {               // 워커가 HTTP 호출에 사용
    "provider": "ollama",
    "endpoint": "http://...",
    "model_name": "gpt-oss:20b",
    "temperature": 0.0,
    "max_tokens": 4096,
    "request_options": {"format": "json"}
  }
}

// 태스크 종료 시
{"action": "done", "output": "최종 답변"}
```

### fn_submit_result 반환 포맷

```jsonc
{"action": "continue"}    // 다음 스텝 진행 (루프 유지)
{"action": "done", "output": "..."}  // 완료
{"action": "wait_subtasks"}          // 서브태스크 완료 대기 중
```

---

## 17. 트러블슈팅

### 워커가 태스크를 처리하지 않는다

```sql
-- 1. 실행 가능 태스크가 있는지 확인
SELECT * FROM alma_public.v_ready_tasks;

-- 2. pending 상태 태스크 확인
SELECT task_id, status, agent_id, created_at
FROM alma_private.tasks WHERE status = 'pending';

-- 3. 의존관계가 막혀있는지 확인 (depends_on 태스크가 완료됐는지)
SELECT td.task_id, dep.status AS dep_status
FROM alma_private.task_dependencies td
JOIN alma_private.tasks dep ON dep.task_id = td.depends_on_task_id
WHERE dep.status <> 'completed';
```

DB_USER 환경변수가 에이전트 `role_name`과 정확히 일치해야 합니다.

---

### create_agent 실패: "role already exists"

```sql
-- PostgreSQL Role은 있지만 ALMA 메타가 없는 경우
-- Role 삭제 후 재생성
DROP ROLE IF EXISTS agent_sql;
SELECT alma_public.create_agent('agent_sql', '{...}'::jsonb);
```

---

### LLM 응답이 JSON이 아니라는 오류

시스템 프롬프트에 JSON 응답 형식을 명시하고, Ollama의 경우 `request_options`에 `{"format": "json"}`을 추가합니다.

```sql
UPDATE alma_private.llm_configs
SET request_options = '{"format": "json"}'
WHERE llm_config_id = (
    SELECT llm_config_id
    FROM alma_private.agent_profile_assignments
    WHERE role_name = 'agent_sql'
);
```

---

### 세션이 'active' 상태로 멈춰있다

워커가 비정상 종료된 경우 수동으로 상태를 정리합니다.

```sql
-- 태스크 취소
UPDATE alma_private.tasks
SET status = 'cancelled'
WHERE session_id = <session_id> AND status IN ('pending','running');

-- 세션 종료
UPDATE alma_private.sessions
SET status = 'failed', completed_at = now()
WHERE session_id = <session_id>;
```

---

### fn_execute_sql: "is not in sql_sandbox_allowlist"

```sql
-- 허용 목록에 뷰 추가
INSERT INTO alma_private.sql_sandbox_allowlist (view_name, description)
VALUES ('alma_public.v_my_tasks', '에이전트 태스크 목록')
ON CONFLICT DO NOTHING;
```

---

### 압축 에이전트 품질 점수가 항상 낮다

모델이 JSON 응답 형식을 정확히 따르지 못하는 경우입니다. temperature를 0으로 내리고 JSON 포맷을 강제합니다.

```sql
UPDATE alma_private.llm_configs
SET temperature      = 0.0,
    request_options  = '{"format": "json"}'
WHERE llm_config_id = (
    SELECT llm_config_id
    FROM alma_private.agent_profile_assignments
    WHERE role_name = 'alma_compressor'
);
```

---

### 에이전트 비밀번호를 잊었다

```sql
-- alma_operator 권한으로 비밀번호 재설정
ALTER ROLE agent_sql PASSWORD 'new_password';
```

---

*ALMA v1.0 — PostgreSQL-native AI Agent Lifecycle Manager*
