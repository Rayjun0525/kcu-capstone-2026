#!/usr/bin/env python3
"""
ALMA Python Worker v1.0
DB가 컨트롤 플레인(fn_next_step/fn_submit_result), 워커가 LLM HTTP 담당.

실행 모드:
  python3 alma_agent.py agent_sql "show me all tables"   # 태스크 등록
  python3 alma_agent.py --worker agent_sql               # 워커
  python3 alma_agent.py --compressor alma_compressor     # 압축 워커

환경변수: DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT
          ALMA_WORKER_POLL_SEC (기본 1.0)
"""
import os, sys, time, json, select, argparse, urllib.request, urllib.error
import psycopg2, psycopg2.extensions, psycopg2.extras


def get_conn(role):
    return psycopg2.connect(
        dbname=os.getenv("DB_NAME","postgres"), user=os.getenv("DB_USER",role),
        password=os.getenv("DB_PASSWORD",""), host=os.getenv("DB_HOST","localhost"),
        port=os.getenv("DB_PORT","5432"),
    )


def call_llm(llm_config, messages):
    """LLM API HTTP 호출. 워커만 담당."""
    provider=llm_config.get("provider","ollama"); endpoint=llm_config.get("endpoint","")
    model=llm_config.get("model_name",""); api_key_ref=llm_config.get("api_key_ref")
    temperature=float(llm_config.get("temperature",0.7)); max_tokens=int(llm_config.get("max_tokens",4096))
    req_opts=llm_config.get("request_options") or {}
    if isinstance(req_opts,str): req_opts=json.loads(req_opts)
    api_key=os.getenv(api_key_ref) if api_key_ref else None
    headers={"Content-Type":"application/json"}

    if provider=="anthropic":
        url=endpoint or "https://api.anthropic.com/v1/messages"
        sys_text=" ".join(m["content"] for m in messages if m.get("role")=="system")
        user_msgs=[m for m in messages if m.get("role")!="system"]
        payload={"model":model,"max_tokens":max_tokens,"temperature":temperature,"messages":user_msgs}
        if sys_text: payload["system"]=sys_text
        payload.update(req_opts)
        headers.update({"x-api-key":api_key or "","anthropic-version":"2023-06-01"})
    elif provider=="openai":
        url=endpoint or "https://api.openai.com/v1/chat/completions"
        payload={"model":model,"max_tokens":max_tokens,"temperature":temperature,"messages":messages}
        payload.update(req_opts); headers["Authorization"]="Bearer "+(api_key or "")
    elif provider=="ollama":
        url=endpoint or "http://localhost:11434/api/chat"
        payload={"model":model,"messages":messages,"stream":False,"options":{"temperature":temperature}}
        payload.update(req_opts)
    else:
        url=endpoint; payload={"model":model,"messages":messages,"temperature":temperature,"max_tokens":max_tokens}
        payload.update(req_opts)
        if api_key: headers["Authorization"]="Bearer "+api_key

    req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers=headers,method="POST")
    with urllib.request.urlopen(req,timeout=120) as resp:
        raw=json.loads(resp.read().decode())

    if provider=="anthropic":   return raw["content"][0]["text"]
    elif provider=="openai":    return raw["choices"][0]["message"]["content"]
    elif provider=="ollama":    return raw["message"]["content"]
    else: return (raw.get("choices",[{}])[0].get("message",{}).get("content")
                  or raw.get("message",{}).get("content") or str(raw))


def execute_task(task_id, conn):
    """fn_next_step/fn_submit_result 루프. DB가 모든 판단, 워커는 HTTP만."""
    conn.autocommit=True
    cur=conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    while True:
        cur.execute("SELECT alma_public.fn_next_step(%s)",(task_id,))
        step=cur.fetchone()["fn_next_step"]
        if step["action"]=="done":
            print(f"  [task {task_id}] done",flush=True); break
        if step["action"]=="call_llm":
            try:
                response=call_llm(step["llm_config"],step["messages"])
            except Exception as e:
                cur.execute("SELECT alma_public.fn_submit_result(%s,%s,TRUE)",(task_id,f"LLM ERROR: {e}"))
                print(f"  [task {task_id}] LLM error: {e}",flush=True); break
            cur.execute("SELECT alma_public.fn_submit_result(%s,%s)",(task_id,response))
            result=cur.fetchone()["fn_submit_result"]
            if result["action"]=="done":
                print(f"  [task {task_id}] completed",flush=True); break
    cur.close()


def run_single(args):
    conn=get_conn(args.agent_role); conn.autocommit=True
    try:
        cur=conn.cursor()
        if args.session_id:
            cur.execute("SELECT alma_public.run_agent(%s,%s,%s,%s,%s)",
                (args.agent_role,args.task,args.session_id,args.memory_limit,args.history_steps))
        else:
            cur.execute("SELECT alma_public.run_agent(%s,%s,NULL,%s,%s)",
                (args.agent_role,args.task,args.memory_limit,args.history_steps))
        task_id=cur.fetchone()[0]
        print(f"Task enqueued. task_id={task_id}")
        print(f"Monitor: SELECT * FROM alma_public.v_my_tasks WHERE task_id={task_id};")
    finally:
        conn.close()


def run_worker(args):
    print(f"[ALMA worker] Starting: {args.agent_role}",flush=True)
    listen_conn=get_conn(args.agent_role); listen_conn.autocommit=True
    listen_conn.cursor().execute("LISTEN alma_task_ready;")
    poll=float(os.getenv("ALMA_WORKER_POLL_SEC","1.0"))
    try:
        while True:
            if select.select([listen_conn],[],[],poll)[0]:
                listen_conn.poll()
                while listen_conn.notifies: listen_conn.notifies.pop(0)

            qconn=get_conn(args.agent_role); qconn.autocommit=False
            try:
                cur=qconn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cur.execute("""
                    SELECT t.task_id FROM alma_private.tasks t
                    JOIN alma_public.v_ready_tasks vr ON vr.task_id=t.task_id
                    JOIN alma_private.agent_meta am ON am.agent_id=t.agent_id
                    WHERE am.role_name=%s ORDER BY t.created_at LIMIT 1 FOR UPDATE OF t SKIP LOCKED
                """,(args.agent_role,))
                row=cur.fetchone()
                if not row:
                    qconn.rollback(); cur.close(); qconn.close(); continue
                task_id=row["task_id"]
                cur.execute("UPDATE alma_private.tasks SET status='running' WHERE task_id=%s",(task_id,))
                qconn.commit(); cur.close(); qconn.close()
            except Exception as e:
                qconn.rollback(); qconn.close()
                print(f"[worker] query error: {e}",flush=True); continue

            print(f"[worker] executing task_id={task_id}",flush=True)
            econn=get_conn(args.agent_role)
            try:
                execute_task(task_id,econn)
            except Exception as e:
                print(f"[worker] task={task_id} FAILED: {e}",flush=True)
                fconn=get_conn(args.agent_role); fconn.autocommit=True
                fconn.cursor().execute(
                    "UPDATE alma_private.tasks SET status='failed',output=%s WHERE task_id=%s",(str(e),task_id))
                fconn.close()
            finally:
                econn.close()
    except KeyboardInterrupt:
        print("[ALMA worker] Stopped.",flush=True)
    finally:
        listen_conn.close()


def run_compressor(args):
    """v_compressible_logs를 폴링하며 LLM으로 로그 압축, 품질 확인 후 원본 삭제."""
    print(f"[ALMA compressor] Starting: {args.agent_role}",flush=True)
    try:
        while True:
            oconn=psycopg2.connect(dbname=os.getenv("DB_NAME","postgres"),
                user=os.getenv("DB_USER","postgres"),password=os.getenv("DB_PASSWORD",""),
                host=os.getenv("DB_HOST","localhost"),port=os.getenv("DB_PORT","5432"))
            oconn.autocommit=True
            ocur=oconn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

            ocur.execute("SELECT * FROM alma_private.system_agent_configs WHERE agent_type='compressor'")
            cfg=ocur.fetchone()
            if not cfg or not cfg["is_enabled"]:
                ocur.close(); oconn.close(); print("[compressor] disabled.",flush=True); time.sleep(60); continue

            s=cfg["settings"] or {}
            qt=float(s.get("quality_threshold",0.9)); rt=float(s.get("retry_threshold",0.8))
            mr=int(s.get("max_retries",2)); bs=int(s.get("batch_size",5))
            ri=int(cfg["run_interval_secs"]); last=cfg["last_run_at"]

            if last:
                import datetime
                elapsed=(datetime.datetime.now(datetime.timezone.utc)-last).total_seconds()
                if elapsed<ri:
                    ocur.close(); oconn.close(); time.sleep(60); continue

            ocur.execute(f"SELECT task_id,total_steps FROM alma_public.v_compressible_logs ORDER BY total_steps DESC LIMIT {bs}")
            targets=ocur.fetchall()

            if not targets:
                ocur.execute("UPDATE alma_private.system_agent_configs SET last_run_at=now() WHERE agent_type='compressor'")
                ocur.close(); oconn.close(); time.sleep(ri); continue

            # LLM 설정 및 시스템 프롬프트 로드
            ocur.execute("""
                SELECT lc.*,ap.system_prompt FROM alma_private.llm_configs lc
                JOIN alma_private.agent_profile_assignments apa ON lc.llm_config_id=apa.llm_config_id
                JOIN alma_private.agent_profiles ap ON ap.profile_id=apa.profile_id
                WHERE apa.role_name=%s
            """,(args.agent_role,))
            lcfg=ocur.fetchone()
            if not lcfg:
                print(f"[compressor] no LLM config for {args.agent_role}",flush=True)
                ocur.close(); oconn.close(); time.sleep(ri); continue

            system_prompt=lcfg["system_prompt"]
            llm_config={k:lcfg[k] for k in ["provider","endpoint","model_name","api_key_ref","temperature","max_tokens","request_options"]}

            for target in targets:
                task_id=target["task_id"]
                ocur.execute("""
                    SELECT step_number,role,content FROM alma_private.execution_logs
                    WHERE task_id=%s AND compressed_at IS NULL ORDER BY step_number
                """,(task_id,))
                logs=ocur.fetchall()
                if not logs: continue

                logs_payload=json.dumps([{"step":r["step_number"],"role":r["role"],"content":r["content"]} for r in logs],ensure_ascii=False)
                messages=[{"role":"system","content":system_prompt},{"role":"user","content":logs_payload}]

                result=None
                for attempt in range(mr+1):
                    try:
                        raw=call_llm(llm_config,messages)
                        parsed=json.loads(raw)
                        quality=float(parsed.get("quality_score",0))
                        print(f"[compressor] task={task_id} attempt={attempt+1} quality={quality:.2f}",flush=True)
                        if quality>=rt:
                            result=parsed; break
                        elif attempt<mr:
                            messages+=[{"role":"assistant","content":raw},
                                       {"role":"user","content":f"Quality {quality:.2f} below {rt}. Re-compress with more detail."}]
                    except Exception as e:
                        print(f"[compressor] LLM error attempt {attempt+1}: {e}",flush=True)

                if not result:
                    print(f"[compressor] task={task_id} all attempts failed, skipping.",flush=True); continue

                quality=float(result.get("quality_score",0))
                summary=json.dumps(result,ensure_ascii=False)
                ocur.execute("""
                    UPDATE alma_private.execution_logs
                    SET compressed_content=%s,compression_quality=%s,compressed_at=now()
                    WHERE task_id=%s AND compressed_at IS NULL
                """,(summary,quality,task_id))

                if quality>=qt:
                    try:
                        ocur.execute("SELECT alma_public.fn_purge_compressed_logs(%s,%s)",(task_id,qt))
                        deleted=ocur.fetchone()[0]
                        print(f"[compressor] task={task_id} purged {deleted} logs",flush=True)
                    except Exception as e:
                        print(f"[compressor] purge failed task={task_id}: {e}",flush=True)
                else:
                    print(f"[compressor] task={task_id} quality {quality:.2f}<{qt}, keeping originals",flush=True)

            ocur.execute("UPDATE alma_private.system_agent_configs SET last_run_at=now() WHERE agent_type='compressor'")
            ocur.close(); oconn.close(); time.sleep(ri)

    except KeyboardInterrupt:
        print("[ALMA compressor] Stopped.",flush=True)


def main():
    p=argparse.ArgumentParser(description="ALMA Worker v1.0")
    p.add_argument("--worker",     action="store_true")
    p.add_argument("--compressor", action="store_true")
    p.add_argument("agent_role",   nargs="?",default=os.getenv("ALMA_AGENT_ROLE"))
    p.add_argument("task",         nargs="?",default=os.getenv("ALMA_TASK"))
    p.add_argument("-s","--session-id",   type=int,default=None)
    p.add_argument("--memory-limit",      type=int,default=5)
    p.add_argument("--history-steps",     type=int,default=20)
    args=p.parse_args()
    if not args.agent_role: p.print_help(); sys.exit(1)
    if args.compressor: run_compressor(args)
    elif args.worker:   run_worker(args)
    else:
        if not args.task: p.print_help(); sys.exit(1)
        run_single(args)

if __name__=="__main__":
    main()
