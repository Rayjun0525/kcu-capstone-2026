#!/usr/bin/env python3
"""
ALMA 압축 에이전트 설정 가이드
────────────────────────────────────────────────────────────────────
압축 에이전트는 Extension 설치 시 프로필만 등록되어 있습니다.
아래 단계를 따라 활성화하세요.

실행 방법:
    psql -U postgres -f alma_compressor_setup.sql
    또는 이 파일을 직접 실행:
    python3 alma_compressor_setup.py
"""

STEP1_CREATE_AGENT = """
-- =========================================================
-- 1단계: 압축 에이전트 생성
--        (gpt-oss:20b 기준 — 실제 모델명으로 변경하세요)
-- =========================================================
SELECT alma_public.create_agent(
    'alma_compressor',
    '{
        "name":          "ALMA Log Compressor",
        "agent_role":    "evaluator",
        "provider":      "ollama",
        "endpoint":      "http://localhost:11434/api/chat",
        "model_name":    "gpt-oss:20b",
        "temperature":   0.1,
        "max_tokens":    4096,
        "request_options": {"format": "json"},
        "max_steps":     20,
        "max_retries":   3
    }'::jsonb
);
-- system_prompt는 Extension 설치 시 등록된 'ALMA Log Compressor' 프로필에서 자동으로 읽어옵니다.
-- 프롬프트를 수정하려면:
--   UPDATE alma_private.agent_profiles
--   SET system_prompt = '...'
--   WHERE name = 'ALMA Log Compressor';
"""

STEP2_LINK_AND_ENABLE = """
-- =========================================================
-- 2단계: system_agent_configs에 에이전트 연결 및 활성화
-- =========================================================
UPDATE alma_private.system_agent_configs
SET role_name  = 'alma_compressor',
    is_enabled = TRUE
WHERE agent_type = 'compressor';
"""

STEP3_CHECK = """
-- =========================================================
-- 3단계: 설정 확인
-- =========================================================
SELECT * FROM alma_public.v_system_agents;
"""

CONTROL_EXAMPLES = """
-- =========================================================
-- 세부 설정 제어 (SQL로 즉시 반영)
-- =========================================================

-- 압축 품질 임계값 상향 (더 엄격하게)
UPDATE alma_private.system_agent_configs
SET settings = settings || '{"quality_threshold": 0.95}'
WHERE agent_type = 'compressor';

-- 실행 주기 변경 (6시간마다)
UPDATE alma_private.system_agent_configs
SET run_interval_secs = 21600
WHERE agent_type = 'compressor';

-- 압축 대상 임계값 낮추기 (10개 이상이면 압축)
UPDATE alma_private.system_agent_configs
SET settings = settings || '{"compress_after_steps": 10}'
WHERE agent_type = 'compressor';

-- 한 번에 처리할 배치 크기 조정
UPDATE alma_private.system_agent_configs
SET settings = settings || '{"batch_size": 10}'
WHERE agent_type = 'compressor';

-- 비활성화
UPDATE alma_private.system_agent_configs
SET is_enabled = FALSE
WHERE agent_type = 'compressor';

-- 압축 대기 태스크 수 확인
SELECT * FROM alma_public.v_compressible_logs;

-- 압축 완료 후 수동 원본 삭제 (운영자 전용)
-- SELECT alma_public.fn_purge_compressed_logs(<task_id>, 0.9);
"""

STEP4_RUN_WORKER = """
# =========================================================
# 4단계: 압축 워커 실행
# =========================================================

# 비밀번호 확인 (생성 시 자동 생성된 경우 재설정 필요)
# psql -U postgres -c "ALTER ROLE alma_compressor PASSWORD 'your_password';"

export DB_USER=alma_compressor
export DB_PASSWORD=your_password

# 압축 워커 실행 (백그라운드)
python3 sample/alma_agent.py --compressor alma_compressor

# 또는 cron으로 주기 실행 (매일 새벽 3시)
# 0 3 * * * DB_USER=alma_compressor DB_PASSWORD=... \\
#   python3 /path/to/alma_agent.py --compressor alma_compressor >> /var/log/alma_compressor.log 2>&1
"""

if __name__ == "__main__":
    print(__doc__)
    print("=" * 60)
    print("psql에서 순서대로 실행하세요:\n")
    print(STEP1_CREATE_AGENT)
    print(STEP2_LINK_AND_ENABLE)
    print(STEP3_CHECK)
    print("\n세부 설정 예시:")
    print(CONTROL_EXAMPLES)
    print("\n워커 실행:")
    print(STEP4_RUN_WORKER)
