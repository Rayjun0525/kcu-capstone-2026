"""
ALMA Dashboard v1.2
- 대시보드 내장 워커: 태스크를 등록하고 fn_next_step/fn_submit_result 루프를
  메인 스레드에서 직접 실행합니다 (스레딩 없음, Streamlit 호환).
- LLM 응답 중 spinner를 띄우고, 완료 후 chat_input을 다시 활성화합니다.
"""
import json
import time
import os
import urllib.request
import urllib.error
import streamlit as st
import psycopg2
import psycopg2.extras
import psycopg2.sql
import pandas as pd
from contextlib import contextmanager

st.set_page_config(page_title="ALMA Dashboard", page_icon="🧠", layout="wide")

st.markdown("""
<style>
.chat-user      { background:var(--secondary-background-color);
                  padding:10px 14px; border-radius:14px 14px 2px 14px;
                  margin:4px 0 4px auto; max-width:78%; text-align:right;
                  font-size:14px; }
.chat-assistant { background:var(--background-color); border:1px solid var(--secondary-background-color);
                  padding:10px 14px; border-radius:14px 14px 14px 2px;
                  margin:4px 0; max-width:84%; font-size:14px; }
.chat-tool      { background:#fff8e1; border-left:3px solid #ffc107;
                  padding:6px 10px; border-radius:4px;
                  margin:2px 0; max-width:84%; font-size:12px; font-family:monospace; }
.chat-thought   { color:#aaa; font-size:12px; font-style:italic; margin:2px 0; }
</style>
""", unsafe_allow_html=True)

PAGES = {
    "🔌 DB 연결":       "db_connect",
    "🤖 에이전트 관리": "agent_mgmt",
    "💬 대화 실행":     "chat_run",
    "📊 세션 모니터링": "monitoring",
    "🗄️ 테이블 탐색기": "table_explorer",
    "🧪 실험 관리":     "experiments",
}

# ──────────────────────────────────────────────────────
# DB 헬퍼
# ──────────────────────────────────────────────────────
def get_conn_params():
    return dict(
        host    = st.session_state.get("db_host",     "localhost"),
        port    = st.session_state.get("db_port",     5432),
        dbname  = st.session_state.get("db_name",     "postgres"),
        user    = st.session_state.get("db_user",     "postgres"),
        password= st.session_state.get("db_password", ""),
    )

@contextmanager
def get_connection(user=None, password=None):
    p = get_conn_params()
    if user:     p["user"]     = user
    if password: p["password"] = password
    conn = psycopg2.connect(**p)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def run_query(sql, params=None):
    with get_connection() as conn:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(sql, params)
        rows = cur.fetchall()
        return pd.DataFrame(rows) if rows else pd.DataFrame()

def run_query_scalar(sql, params=None):
    with get_connection() as conn:
        cur = conn.cursor()
        cur.execute(sql, params)
        row = cur.fetchone()
        return row[0] if row else None

def is_connected():
    return st.session_state.get("db_connected", False)

def test_connection():
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM pg_extension WHERE extname='alma'")
            if not cur.fetchone(): return "no_extension"
            cur.execute("SELECT pg_has_role(session_user,'alma_operator','MEMBER')")
            if not cur.fetchone()[0]: return "no_operator"
        return "ok"
    except Exception:
        return "conn_error"

# ──────────────────────────────────────────────────────
# LLM HTTP 호출
# ──────────────────────────────────────────────────────
def call_llm(llm_config: dict, messages: list) -> str:
    provider    = llm_config.get("provider", "ollama")
    endpoint    = llm_config.get("endpoint") or ""
    model       = llm_config.get("model_name", "")
    api_key_ref = llm_config.get("api_key_ref")
    temperature = float(llm_config.get("temperature", 0.7))
    max_tokens  = int(llm_config.get("max_tokens", 4096))
    req_opts    = llm_config.get("request_options") or {}
    if isinstance(req_opts, str):
        req_opts = json.loads(req_opts)

    api_key = os.getenv(api_key_ref) if api_key_ref else None
    headers = {"Content-Type": "application/json"}

    if provider == "anthropic":
        url      = endpoint or "https://api.anthropic.com/v1/messages"
        sys_text = " ".join(m["content"] for m in messages if m.get("role") == "system")
        user_msgs = [m for m in messages if m.get("role") != "system"]
        payload  = {"model": model, "max_tokens": max_tokens,
                    "temperature": temperature, "messages": user_msgs}
        if sys_text: payload["system"] = sys_text
        payload.update(req_opts)
        headers.update({"x-api-key": api_key or "",
                         "anthropic-version": "2023-06-01"})
    elif provider == "openai":
        url     = endpoint or "https://api.openai.com/v1/chat/completions"
        payload = {"model": model, "max_tokens": max_tokens,
                   "temperature": temperature, "messages": messages}
        payload.update(req_opts)
        headers["Authorization"] = "Bearer " + (api_key or "")
    elif provider == "ollama":
        url     = endpoint or "http://localhost:11434/api/chat"
        payload = {"model": model, "messages": messages,
                   "stream": False, "options": {"temperature": temperature}}
        payload.update(req_opts)
    else:
        url     = endpoint
        payload = {"model": model, "messages": messages,
                   "temperature": temperature, "max_tokens": max_tokens}
        payload.update(req_opts)
        if api_key: headers["Authorization"] = "Bearer " + api_key

    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=120) as resp:
        raw = json.loads(resp.read().decode("utf-8"))

    if provider == "anthropic": return raw["content"][0]["text"]
    elif provider == "openai":  return raw["choices"][0]["message"]["content"]
    elif provider == "ollama":  return raw["message"]["content"]
    else:
        return (raw.get("choices",[{}])[0].get("message",{}).get("content")
                or raw.get("message",{}).get("content") or str(raw))

# ──────────────────────────────────────────────────────
# 인라인 워커 — 메인 스레드에서 직접 실행
# ──────────────────────────────────────────────────────
def run_task_inline(task_id: int, agent_role: str, agent_pw: str) -> list:
    """
    fn_next_step / fn_submit_result 루프를 동기로 실행합니다.
    실행 중 Streamlit spinner를 표시하고, 완료 시 대화 로그를 반환합니다.
    """
    conn_params = get_conn_params()
    conn_params["user"]     = agent_role
    conn_params["password"] = agent_pw

    conn = psycopg2.connect(**conn_params)
    conn.autocommit = True
    cur  = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    chat_entries = []   # {"role": ..., "content": ...}
    step_count   = 0

    status_placeholder = st.empty()
    log_placeholder    = st.empty()

    def refresh_display():
        with log_placeholder.container():
            for e in chat_entries:
                _render_entry(e)

    try:
        while True:
            step_count += 1
            status_placeholder.caption(f"⚙️ step {step_count} — fn_next_step 호출 중…")

            cur.execute("SELECT alma_public.fn_next_step(%s)", (task_id,))
            step = cur.fetchone()["fn_next_step"]

            if step["action"] == "done":
                output = step.get("output") or ""
                # done 이면 최종 답변이 이미 execution_logs에 있으므로
                # 마지막 assistant 항목이 없을 때만 추가
                if not any(e["role"] == "assistant" for e in chat_entries):
                    chat_entries.append({"role": "assistant", "content": output})
                status_placeholder.empty()
                refresh_display()
                break

            if step["action"] == "call_llm":
                status_placeholder.caption(f"⚙️ step {step_count} — LLM 호출 중… ({step['llm_config'].get('model_name','')})")

                try:
                    response = call_llm(step["llm_config"], step["messages"])
                except Exception as e:
                    cur.execute(
                        "SELECT alma_public.fn_submit_result(%s, %s, TRUE)",
                        (task_id, f"LLM ERROR: {e}")
                    )
                    chat_entries.append({"role": "error", "content": f"LLM 오류: {e}"})
                    status_placeholder.empty()
                    refresh_display()
                    break

                # 응답 파싱 → 화면 표시
                try:
                    parsed = json.loads(response)
                    action = parsed.get("action", "")
                    thought = parsed.get("thought", "")

                    if thought:
                        chat_entries.append({"role": "thought", "content": thought})

                    if action == "finish":
                        final = parsed.get("final_answer", response)
                        chat_entries.append({"role": "assistant", "content": final})
                    elif action == "execute_sql":
                        sql_stmt = parsed.get("sql", "")
                        chat_entries.append({"role": "tool_input", "content": sql_stmt})
                    else:
                        # 기타 액션 또는 일반 텍스트
                        content = parsed.get("content") or parsed.get("message") or response
                        if content and action not in ("delegate",):
                            chat_entries.append({"role": "assistant", "content": content})

                except (json.JSONDecodeError, TypeError):
                    # JSON 아니면 그냥 텍스트로
                    chat_entries.append({"role": "assistant", "content": response})

                refresh_display()

                # DB에 결과 반납
                status_placeholder.caption(f"⚙️ step {step_count} — fn_submit_result 호출 중…")
                cur.execute(
                    "SELECT alma_public.fn_submit_result(%s, %s)",
                    (task_id, response)
                )
                result = cur.fetchone()["fn_submit_result"]

                # tool 결과 있으면 표시
                if result.get("tool_result"):
                    chat_entries.append({"role": "tool_result",
                                         "content": str(result["tool_result"])})
                    refresh_display()

                if result["action"] == "done":
                    status_placeholder.empty()
                    refresh_display()
                    break
                # action == "continue" → 루프 계속

    except Exception as e:
        chat_entries.append({"role": "error", "content": f"워커 오류: {e}"})
        status_placeholder.empty()
        refresh_display()

    finally:
        conn.close()
        status_placeholder.empty()

    log_placeholder.empty()   # 임시 렌더 지우기 (history에서 다시 그릴 예정)
    return chat_entries


def _render_entry(e: dict):
    role    = e["role"]
    content = e["content"]
    if role == "assistant":
        st.markdown(
            f'<div class="chat-assistant">{content}</div>',
            unsafe_allow_html=True)
    elif role == "thought":
        st.markdown(
            f'<div class="chat-thought">💭 {content}</div>',
            unsafe_allow_html=True)
    elif role == "tool_input":
        st.markdown(
            f'<div class="chat-tool">🔧 SQL<br><code>{content}</code></div>',
            unsafe_allow_html=True)
    elif role == "tool_result":
        preview = content[:500] + ("…" if len(content) > 500 else "")
        st.markdown(
            f'<div class="chat-tool">📋 결과<br><code>{preview}</code></div>',
            unsafe_allow_html=True)
    elif role == "error":
        st.error(content)


# ──────────────────────────────────────────────────────
# 사이드바
# ──────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("# 🧠 ALMA")
    st.markdown("**Agent Lifecycle Manager**")
    st.markdown("---")
    if is_connected():
        st.success(f"✅ {st.session_state.get('db_user','')}@"
                   f"{st.session_state.get('db_host','')}/"
                   f"{st.session_state.get('db_name','')}")
    else:
        st.warning("⚠️ DB 미연결")
    st.markdown("---")
    page = st.radio("메뉴", list(PAGES.keys()), label_visibility="collapsed")

# ──────────────────────────────────────────────────────
# DB 연결
# ──────────────────────────────────────────────────────
def page_db_connect():
    st.header("🔌 데이터베이스 연결")
    c1, c2 = st.columns(2)
    with c1:
        host   = st.text_input("호스트",       value=st.session_state.get("db_host","localhost"))
        port   = st.number_input("포트",        value=st.session_state.get("db_port",5432),
                                  min_value=1, max_value=65535)
        dbname = st.text_input("데이터베이스",  value=st.session_state.get("db_name","postgres"))
    with c2:
        user   = st.text_input("사용자명",      value=st.session_state.get("db_user","postgres"))
        pw     = st.text_input("비밀번호",       value=st.session_state.get("db_password",""),
                                type="password")

    if st.button("🔗 연결 테스트", type="primary", use_container_width=True):
        st.session_state.update({"db_host": host, "db_port": int(port),
                                  "db_name": dbname, "db_user": user, "db_password": pw})
        with st.spinner("연결 중…"):
            result = test_connection()
        if result == "ok":
            st.session_state["db_connected"] = True
            st.success("✅ 연결 성공!")
            st.balloons()
        elif result == "no_extension":
            st.error("❌ ALMA 미설치. `CREATE EXTENSION alma;`")
            st.session_state["db_connected"] = False
        elif result == "no_operator":
            st.error(f"❌ alma_operator 권한 없음. `GRANT alma_operator TO {user};`")
            st.session_state["db_connected"] = False
        else:
            st.error("❌ 연결 실패.")
            st.session_state["db_connected"] = False

# ──────────────────────────────────────────────────────
# 에이전트 관리
# ──────────────────────────────────────────────────────
def page_agent_mgmt():
    st.header("🤖 에이전트 관리")
    if not is_connected():
        st.warning("먼저 DB에 연결하세요."); return

    tab_list, tab_create, tab_edit, tab_delete = st.tabs(
        ["목록", "에이전트 생성", "설정 수정", "삭제"])

    with tab_list:
        try:
            df = run_query("SELECT * FROM alma_public.list_agents()")
            st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty                 else st.info("등록된 에이전트가 없습니다.")
        except Exception as e:
            st.error(f"목록 조회 실패: {e}")

    with tab_create:
        c1, c2 = st.columns(2)
        with c1:
            role_name     = st.text_input("Role 이름",   placeholder="agent_sql",           key="ca_role")
            display_name  = st.text_input("표시 이름",   placeholder="SQL 분석 에이전트",    key="ca_name")
            agent_role_t  = st.selectbox("에이전트 역할",
                                         ["executor","orchestrator","evaluator"],              key="ca_role_t")
            system_prompt = st.text_area("시스템 프롬프트", height=180,
                placeholder=(
                    '당신은 SQL 전문가입니다. 항상 JSON으로 응답하세요.\n'
                    '완료: {"thought":"...","action":"finish","final_answer":"..."}\n'
                    'SQL: {"thought":"...","action":"execute_sql","sql":"SELECT ..."}'
                ),
                key="ca_sysprompt")
        with c2:
            provider      = st.selectbox("LLM 제공자",
                                         ["ollama","openai","anthropic","custom"],             key="ca_prov")
            ep_defaults   = {"ollama":"http://localhost:11434/api/chat",
                             "openai":"https://api.openai.com/v1/chat/completions",
                             "anthropic":"https://api.anthropic.com/v1/messages","custom":""}
            endpoint      = st.text_input("엔드포인트", value=ep_defaults.get(provider,""),  key="ca_ep")
            model_name    = st.text_input("모델명",      placeholder="gpt-oss:20b",           key="ca_model")
            emb_model     = st.text_input("임베딩 모델 (선택)",                               key="ca_emb")
            api_key_ref   = st.text_input("API 키 환경변수명", placeholder="OPENAI_API_KEY",  key="ca_apiref")
            temperature   = st.slider("Temperature", 0.0, 2.0, 0.7, 0.1,                     key="ca_temp")
            max_tokens    = st.number_input("Max Tokens", min_value=1, value=4096,            key="ca_maxtok")
            req_opts_str  = st.text_input('Request Options (JSON)', placeholder='{"format":"json"}', key="ca_reqopts",
                                          help='비워두면 적용 안 됨. Ollama JSON 모드: {"format":"json"}')
            max_steps     = st.number_input("최대 스텝", min_value=1, value=10,               key="ca_maxsteps")
            max_retries   = st.number_input("최대 재시도", min_value=0, value=3,              key="ca_maxretry")
            pwd           = st.text_input("DB 비밀번호 (빈칸=자동생성)", type="password",     key="ca_pwd")

        if st.button("✅ 에이전트 생성", type="primary", key="btn_create"):
            if not role_name or not display_name or not model_name:
                st.warning("role_name, 표시이름, 모델명은 필수입니다.")
            else:
                # req_opts_str 검증
                parsed_req_opts = None
                if req_opts_str.strip():
                    try:
                        parsed_req_opts = json.loads(req_opts_str.strip())
                    except json.JSONDecodeError as je:
                        st.error("Request Options JSON 오류: " + str(je) + '  ← 예: {"format":"json"}')
                        st.stop()
                try:
                    config = {"name": display_name, "agent_role": agent_role_t,
                              "provider": provider, "endpoint": endpoint,
                              "model_name": model_name, "temperature": float(temperature),
                              "max_tokens": int(max_tokens), "system_prompt": system_prompt,
                              "max_steps": int(max_steps), "max_retries": int(max_retries)}
                    if emb_model.strip():   config["embedding_model"] = emb_model.strip()
                    if api_key_ref.strip(): config["api_key_ref"]     = api_key_ref.strip()
                    if parsed_req_opts:     config["request_options"] = parsed_req_opts
                    if pwd:                 config["password"]        = pwd
                    result = run_query_scalar(
                        "SELECT alma_public.create_agent(%s,%s::jsonb)",
                        (role_name, json.dumps(config, ensure_ascii=False)))
                    st.success(f"✅ {result}")
                except Exception as e:
                    st.error(f"생성 실패: {e}")

    with tab_edit:
        try:
            ag = run_query("SELECT role_name FROM alma_public.list_agents()")
        except Exception as e:
            st.error(f"에이전트 목록 조회 실패: {e}")
            ag = None
        if ag is None or ag.empty:
            st.info("에이전트가 없습니다.")
        else:
            sel = st.selectbox("에이전트 선택", ag["role_name"].tolist(), key="edit_sel")
            try:
                info = run_query("""
                    SELECT ap.system_prompt, ap.max_steps, ap.max_retries,
                           lc.model_name, lc.temperature, lc.max_tokens, lc.endpoint,
                           lc.request_options
                    FROM alma_private.agent_profile_assignments apa
                    JOIN alma_private.agent_profiles ap ON ap.profile_id=apa.profile_id
                    JOIN alma_private.llm_configs lc ON lc.llm_config_id=apa.llm_config_id
                    WHERE apa.role_name=%s""", (sel,))
            except Exception as e:
                st.error(f"에이전트 정보 조회 실패: {e}")
                info = None
            if info is not None and not info.empty:
                row = info.iloc[0]
                new_prompt = st.text_area("시스템 프롬프트",
                                          value=str(row.get("system_prompt") or ""),
                                          height=150, key="edit_prompt")
                ec1, ec2 = st.columns(2)
                with ec1:
                    new_model  = st.text_input("모델명",
                                               value=str(row.get("model_name") or ""),        key="edit_model")
                    new_temp   = st.slider("Temperature", 0.0, 2.0,
                                           float(row.get("temperature") or 0.7), 0.1,         key="edit_temp")
                    new_steps  = st.number_input("최대 스텝", min_value=1,
                                                  value=int(row.get("max_steps") or 10),      key="edit_steps")
                with ec2:
                    new_ep     = st.text_input("엔드포인트",
                                               value=str(row.get("endpoint") or ""),          key="edit_ep")
                    new_maxtok = st.number_input("Max Tokens", min_value=1,
                                                  value=int(row.get("max_tokens") or 4096),   key="edit_maxtok")
                    new_retry  = st.number_input("최대 재시도", min_value=0,
                                                  value=int(row.get("max_retries") or 3),     key="edit_retry")
                    # request_options 편집
                    cur_req = row.get("request_options")
                    cur_req_str = json.dumps(cur_req, ensure_ascii=False) if cur_req else ""
                    new_req_str = st.text_input("Request Options (JSON)",
                                                value=cur_req_str,                             key="edit_reqopts",
                                                help='비워두면 NULL로 저장. 예: {"format":"json"}')
                if st.button("💾 저장", type="primary", key="btn_edit_save"):
                    # request_options 검증
                    new_req_opts = None
                    if new_req_str.strip():
                        try:
                            new_req_opts = json.loads(new_req_str.strip())
                        except json.JSONDecodeError as je:
                            st.error("Request Options JSON 오류: " + str(je))
                            st.stop()
                    try:
                        with get_connection() as conn:
                            cur = conn.cursor()
                            cur.execute("""
                                UPDATE alma_private.agent_profiles ap
                                SET system_prompt=%s, max_steps=%s, max_retries=%s
                                FROM alma_private.agent_profile_assignments apa
                                WHERE ap.profile_id=apa.profile_id AND apa.role_name=%s
                            """, (new_prompt, int(new_steps), int(new_retry), sel))
                            cur.execute("""
                                UPDATE alma_private.llm_configs lc
                                SET model_name=%s, temperature=%s, max_tokens=%s,
                                    endpoint=%s, request_options=%s::jsonb
                                FROM alma_private.agent_profile_assignments apa
                                WHERE lc.llm_config_id=apa.llm_config_id AND apa.role_name=%s
                            """, (new_model, float(new_temp), int(new_maxtok),
                                  new_ep,
                                  json.dumps(new_req_opts) if new_req_opts else None,
                                  sel))
                        st.success("✅ 저장 완료")
                    except Exception as e:
                        st.error(f"저장 실패: {e}")

    with tab_delete:
        st.warning("⚠️ 에이전트와 모든 관련 데이터가 영구 삭제됩니다.")
        try:
            ag = run_query("SELECT role_name FROM alma_public.list_agents()")
        except Exception as e:
            st.error(f"에이전트 목록 조회 실패: {e}")
            ag = None
        if ag is None or ag.empty:
            st.info("에이전트가 없습니다.")
        else:
            del_sel = st.selectbox("삭제 대상", ag["role_name"].tolist(), key="del_sel")
            confirm = st.text_input(f'확인: "{del_sel}" 를 입력하세요', key="del_confirm")
            if st.button("🗑️ 삭제", type="primary", key="btn_delete"):
                if confirm != del_sel:
                    st.warning("에이전트 이름을 정확히 입력하세요.")
                else:
                    try:
                        result = run_query_scalar("SELECT alma_public.drop_agent(%s)", (del_sel,))
                        st.success(f"✅ {result}")
                    except Exception as e:
                        st.error(f"삭제 실패: {e}")

# ──────────────────────────────────────────────────────
# 💬 대화 실행 (핵심)
# ──────────────────────────────────────────────────────
def page_chat_run():
    st.header("💬 대화 실행")
    if not is_connected():
        st.warning("먼저 DB에 연결하세요."); return

    # session_state 초기화 — 에이전트별로 분리
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = {}    # {agent_role: [...]}
    if "chat_session_id" not in st.session_state:
        st.session_state["chat_session_id"] = {} # {agent_role: session_id | None}

    # ── 에이전트 선택
    try:
        agents_df = run_query("SELECT role_name, agent_role FROM alma_public.list_agents()")
    except Exception as e:
        st.error(f"에이전트 목록 조회 실패: {e}"); return

    if agents_df.empty:
        st.info("먼저 에이전트를 생성하세요."); return

    col_a, col_b, col_c = st.columns([3, 3, 1])
    with col_a:
        agent_role = st.selectbox(
            "에이전트",
            agents_df["role_name"].tolist(), key="chat_sel_role",
            format_func=lambda r:
                f"{r}  ({agents_df[agents_df['role_name']==r]['agent_role'].iloc[0]})"
        )
    with col_b:
        agent_pw = st.text_input(
            "에이전트 DB 비밀번호", type="password", key="chat_pw",
            help="에이전트 롤로 직접 접속하기 위해 필요합니다")
    with col_c:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🗑️ 초기화", key="chat_clear"):
            st.session_state["chat_history"][agent_role]    = []
            st.session_state["chat_session_id"][agent_role] = None
            st.rerun()

    # 에이전트별 슬롯 초기화 — DB에서 마지막 세션 자동 복원
    if agent_role not in st.session_state["chat_session_id"]:
        last_sid = run_query_scalar("""
            SELECT s.session_id
            FROM alma_private.sessions s
            JOIN alma_private.agent_meta am ON am.agent_id = s.agent_id
            WHERE am.role_name = %s AND s.status = 'active'
            ORDER BY s.session_id DESC LIMIT 1
        """, (agent_role,))
        st.session_state["chat_session_id"][agent_role] = last_sid

    if agent_role not in st.session_state["chat_history"]:
        last_sid = st.session_state["chat_session_id"].get(agent_role)
        if last_sid:
            try:
                logs = run_query("""
                    SELECT el.role, el.content
                    FROM alma_private.tasks t
                    JOIN alma_private.execution_logs el ON el.task_id = t.task_id
                    WHERE t.session_id = %s
                      AND el.role IN ('user', 'assistant')
                    ORDER BY t.task_id, el.step_number
                """, (last_sid,))
                history = []
                for _, row in logs.iterrows():
                    role = "user" if row["role"] == "user" else "assistant"
                    history.append({"role": role, "content": row["content"]})
                st.session_state["chat_history"][agent_role] = history
            except Exception:
                st.session_state["chat_history"][agent_role] = []
        else:
            st.session_state["chat_history"][agent_role] = []

    # 현재 세션 표시
    cur_session_id = st.session_state["chat_session_id"].get(agent_role)

    col_m, col_s = st.columns([1, 3])
    with col_m:
        mem_limit = st.number_input("메모리 참조 수", min_value=0, value=5, key="chat_mem")
    with col_s:
        keep_session = st.checkbox(
            "같은 세션으로 연속 대화", value=True, key="chat_keep_sess",
            help="체크 시 이전 대화 맥락을 유지합니다")

    if keep_session and cur_session_id:
        st.caption(f"🔗 현재 세션 session_id={cur_session_id}  (초기화 버튼으로 새 세션 시작)")
    elif keep_session:
        st.caption("💬 첫 메시지를 보내면 새 세션이 시작됩니다.")

    st.markdown("---")

    # ── 대화 이력 렌더링 (에이전트별)
    for entry in st.session_state["chat_history"][agent_role]:
        role    = entry["role"]
        content = entry["content"]
        if role == "user":
            st.markdown(
                f'<div class="chat-user">{content}</div>',
                unsafe_allow_html=True)
        else:
            _render_entry(entry)

    # ── 입력창 (chat_input은 항상 최하단에 고정됨)
    user_input = st.chat_input(
        "메시지를 입력하세요… (에이전트 비밀번호 입력 필수)",
        key="chat_input_box")

    if not user_input:
        return   # 입력 없으면 종료

    # 비밀번호 확인
    if not agent_pw:
        st.error("에이전트 DB 비밀번호를 입력하세요.")
        return

    # 에이전트 롤 접속 테스트
    try:
        p = get_conn_params()
        p["user"] = agent_role; p["password"] = agent_pw
        test = psycopg2.connect(**p, connect_timeout=5)
        test.close()
    except Exception as e:
        st.error(f"에이전트 접속 실패: {e}")
        return

    # 사용자 메시지 즉시 표시
    st.session_state["chat_history"][agent_role].append({"role": "user", "content": user_input})
    st.markdown(f'<div class="chat-user">{user_input}</div>', unsafe_allow_html=True)

    # ── run_agent (에이전트 롤로 접속해서 호출)
    session_id = st.session_state["chat_session_id"].get(agent_role) if keep_session else None
    try:
        p = get_conn_params()
        p["user"] = agent_role; p["password"] = agent_pw
        conn_ag = psycopg2.connect(**p)
        conn_ag.autocommit = True
        cur_ag  = conn_ag.cursor()
        if session_id:
            cur_ag.execute(
                "SELECT alma_public.run_agent(%s,%s,%s,%s,%s)",
                (agent_role, user_input, session_id, int(mem_limit), 20))
        else:
            cur_ag.execute(
                "SELECT alma_public.run_agent(%s,%s,NULL,%s,%s)",
                (agent_role, user_input, int(mem_limit), 20))
        task_id = cur_ag.fetchone()[0]
        conn_ag.close()
    except Exception as e:
        st.error(f"태스크 등록 실패: {e}")
        return

    # 새 세션이면 session_id 저장 (operator 커넥션으로 alma_private.tasks 조회)
    if keep_session and not session_id:
        try:
            new_sid = run_query_scalar(
                "SELECT session_id FROM alma_private.tasks WHERE task_id=%s", (task_id,))
            if new_sid:
                st.session_state["chat_session_id"][agent_role] = new_sid
        except Exception:
            pass

    # ── 인라인 워커 실행 (동기, 메인 스레드)
    with st.spinner(f"⚙️ 에이전트 처리 중… (task_id={task_id})"):
        result_entries = run_task_inline(task_id, agent_role, agent_pw)

    # 결과를 에이전트별 history에 추가
    for e in result_entries:
        st.session_state["chat_history"][agent_role].append(e)

    # 화면 갱신 (history 전체를 다시 그림)
    st.rerun()

# ──────────────────────────────────────────────────────
# 세션 모니터링
# ──────────────────────────────────────────────────────
def page_monitoring():
    st.header("📊 세션 모니터링")
    if not is_connected():
        st.warning("먼저 DB에 연결하세요."); return

    try:
        stats = run_query("""
            SELECT COUNT(*) AS total,
                   COUNT(*) FILTER (WHERE status='active')    AS active,
                   COUNT(*) FILTER (WHERE status='completed') AS completed,
                   COUNT(*) FILTER (WHERE status='failed')    AS failed
            FROM alma_private.sessions""")
        if not stats.empty:
            r = stats.iloc[0]
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("전체 세션", int(r["total"]))
            c2.metric("활성",      int(r["active"]))
            c3.metric("완료",      int(r["completed"]))
            c4.metric("실패",      int(r["failed"]))
    except Exception: pass

    st.markdown("---")
    t1, t2, t3 = st.tabs(["태스크 현황", "세션 목록", "감사 로그"])

    with t1:
        try:
            df = run_query("""
                SELECT t.task_id, am.role_name, t.status,
                       left(t.input,60) AS input_preview,
                       left(t.output,60) AS output_preview,
                       t.created_at, t.updated_at
                FROM alma_private.tasks t
                JOIN alma_private.agent_meta am ON am.agent_id=t.agent_id
                ORDER BY t.task_id DESC LIMIT 50""")
            st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty \
                else st.info("태스크가 없습니다.")
        except Exception as e: st.error(f"{e}")

    with t2:
        try:
            df = run_query("""
                SELECT s.session_id, am.role_name, s.status,
                       left(s.goal,50) AS goal, s.started_at, s.completed_at,
                       left(s.final_answer,60) AS answer_preview
                FROM alma_private.sessions s
                JOIN alma_private.agent_meta am ON am.agent_id=s.agent_id
                ORDER BY s.session_id DESC LIMIT 50""")
            if not df.empty:
                sid = st.selectbox("세션 선택 → 스텝 보기",
                                   ["(선택 안 함)"] + df["session_id"].tolist(),
                                   key="mon_sid")
                st.dataframe(df, use_container_width=True, hide_index=True)
                if sid != "(선택 안 함)":
                    detail = run_query("SELECT * FROM alma_public.get_session(%s)", (int(sid),))
                    st.dataframe(detail, use_container_width=True, hide_index=True)
            else:
                st.info("세션이 없습니다.")
        except Exception as e: st.error(f"{e}")

    with t3:
        try:
            df = run_query("""
                SELECT * FROM alma_public.v_session_audit
                ORDER BY session_id DESC, task_id, step_number LIMIT 200""")
            st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty \
                else st.info("감사 로그가 없습니다.")
        except Exception as e: st.error(f"{e}")

    if st.button("🔄 새로고침", key="mon_refresh"):
        st.rerun()

# ──────────────────────────────────────────────────────
# 테이블 탐색기
# ──────────────────────────────────────────────────────
def page_table_explorer():
    st.header("🗄️ 테이블 탐색기")
    if not is_connected():
        st.warning("먼저 DB에 연결하세요."); return

    TABLES = [
        "alma_private.tasks", "alma_private.sessions",
        "alma_private.execution_logs", "alma_private.agent_meta",
        "alma_private.llm_configs", "alma_private.agent_profiles",
        "alma_private.memory", "alma_private.task_dependencies",
        "alma_private.system_agent_configs", "alma_private.sql_sandbox_allowlist",
        "alma_public.v_ready_tasks", "alma_public.v_compressible_logs",
        "alma_public.v_system_agents",
    ]
    sel   = st.selectbox("테이블/뷰", TABLES, key="te_tbl")
    limit = st.number_input("최대 행 수", min_value=1, value=50, key="te_limit")
    order = st.text_input("정렬 컬럼 (선택)", key="te_order")

    if st.button("조회", type="primary", key="te_btn"):
        try:
            order_sql = f"ORDER BY {order} DESC" if order.strip() else ""
            df = run_query(f"SELECT * FROM {sel} {order_sql} LIMIT %s", (int(limit),))
            st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty \
                else st.info("데이터가 없습니다.")
        except Exception as e:
            st.error(f"조회 실패: {e}")

# ──────────────────────────────────────────────────────
# 실험 관리
# ──────────────────────────────────────────────────────
def page_experiments():
    st.header("🧪 실험 관리")
    if not is_connected():
        st.warning("먼저 DB에 연결하세요."); return

    t1, t2, t3 = st.tabs(["목록", "새 실험", "결과 비교"])
    with t1:
        try:
            df = run_query("SELECT * FROM alma_private.experiments ORDER BY created_at DESC")
            st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty \
                else st.info("실험이 없습니다.")
        except Exception as e: st.error(f"{e}")

    with t2:
        name = st.text_input("실험 이름",       key="exp_name")
        task = st.text_area("태스크 프롬프트",  key="exp_task", height=100)
        desc = st.text_area("설명 (선택)",       key="exp_desc", height=60)
        if st.button("등록", type="primary", key="exp_reg"):
            if name and task:
                try:
                    with get_connection() as conn:
                        conn.cursor().execute(
                            "INSERT INTO alma_private.experiments(name,task_prompt,description) VALUES(%s,%s,%s)",
                            (name, task, desc or None))
                    st.success("✅ 등록 완료")
                except Exception as e: st.error(f"{e}")
            else:
                st.warning("이름과 태스크 프롬프트는 필수입니다.")

    with t3:
        try:
            exps = run_query("SELECT experiment_id,name FROM alma_private.experiments")
            if not exps.empty:
                sel_exp = st.selectbox("실험 선택", exps["experiment_id"].tolist(),
                    format_func=lambda i: f"#{i} {exps[exps['experiment_id']==i]['name'].iloc[0]}",
                    key="res_sel")
                df = run_query(
                    "SELECT * FROM alma_private.experiment_results WHERE experiment_id=%s ORDER BY created_at",
                    (int(sel_exp),))
                st.dataframe(df, use_container_width=True, hide_index=True) if not df.empty \
                    else st.info("결과 데이터가 없습니다.")
        except Exception as e: st.error(f"{e}")

# ──────────────────────────────────────────────────────
# 라우팅
# ──────────────────────────────────────────────────────
{
    "🔌 DB 연결":       page_db_connect,
    "🤖 에이전트 관리": page_agent_mgmt,
    "💬 대화 실행":     page_chat_run,
    "📊 세션 모니터링": page_monitoring,
    "🗄️ 테이블 탐색기": page_table_explorer,
    "🧪 실험 관리":     page_experiments,
}[page]()
