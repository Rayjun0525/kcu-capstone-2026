# ALMA — Agent Lifecycle Manager v1.0

PostgreSQL Extension 기반 AI 에이전트 라이프사이클 관리 프레임워크.

## 설치

```bash
sudo apt install postgresql-16-pgvector postgresql-plpython3-16
cd alma && make install
psql -U postgres -c "CREATE EXTENSION alma;"
psql -U postgres -c "GRANT alma_operator TO postgres;"
```

## 파일 구조

```
alma/
├── alma.control
├── Makefile
├── Manual.md           한글 상세 사용설명서
├── sql/
│   └── alma--1.0.sql
└── sample/
    ├── alma_agent.py        Python 워커 + 압축 데몬
    ├── alma_dashboard.py    Streamlit 대시보드
    └── requirements.txt
```

자세한 내용은 **Manual.md**를 참조하세요.
